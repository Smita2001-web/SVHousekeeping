<?php include("header.php"); ?>
<!-- hero-section -->
<div class="hero-slider owl-carousel owl-theme">
    <div class="hero-single" style="background: url(img/bg-img1.jpg)">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-10 mx-auto">
                    <div class="hero-content text-center">
                        <h6 class="hero-sub-title" data-animation="fadeInUp" data-delay=".25s">Spaces that speak, sing, and inspire</h6><br><br>
                        <h1 class="hero-title" data-animation="fadeInRight" data-delay=".50s">
                            Home <span>Theatres</span> 
                        </h1>
                        <p data-animation="fadeInLeft" data-delay=".75s">
                           Transform your living room into a cinematic experience <br> with immersive sound and precision-tuned home theatre solutions.
                        </p><br>
                        <div class="hero-btn justify-content-center" data-animation="fadeInUp" data-delay="1s">
                            <a href="#" class="theme-btn">Explore More<i
                                    class="fas fa-circle-arrow-right"></i></a>
                            <!--<a href="#" class="theme-btn theme-btn2">Latest Episode<i-->
                            <!--        class="fas fa-circle-arrow-right"></i></a>-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="hero-single" style="background: url(img/banner-img60.jpg)">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-10 mx-auto">
                    <div class="hero-content text-center">
                        <h6 class="hero-sub-title" data-animation="fadeInUp" data-delay=".25s">From Studio to Stage – Sound That Speaks</h6><br><br>
                        <h1 class="hero-title" data-animation="fadeInRight" data-delay=".50s">
                          Acoustic  <span> Consultancy</span> 
                        </h1>
                        <p data-animation="fadeInLeft" data-delay=".75s">
                          Enhance your space with expert acoustic consultancy tailored <br>for studios, halls, institutions, and premium audio environments
                        </p>
                        <br>
                        <div class="hero-btn justify-content-center" data-animation="fadeInUp" data-delay="1s">
                            <a href="#" class="theme-btn">Explore More<i
                                    class="fas fa-circle-arrow-right"></i></a>
                            <!--<a href="#" class="theme-btn theme-btn2">Latest Episode<i-->
                            <!--        class="fas fa-circle-arrow-right"></i></a>-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="hero-single" style="background: url(img/banner-img58.jpg)">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-10 mx-auto">
                    <div class="hero-content text-center">
                        <h6 class="hero-sub-title" data-animation="fadeInUp" data-delay=".25s">From Studio to Stage – Sound That Speaks</h6>
                        <h1 class="hero-title" data-animation="fadeInRight" data-delay=".50s">
                             Dolby  <span>Atmos </span>  Consultancy
                        </h1>
                        <p data-animation="fadeInLeft" data-delay=".75s">
                     Unlock true 3D audio with our Dolby Atmos consultancy – <br> precision design and setup for immersive, next-level sound environments
                        </p>
                        <br>
                        <div class="hero-btn justify-content-center" data-animation="fadeInUp" data-delay="1s">
                            <a href="#" class="theme-btn">Explore More<i
                                    class="fas fa-circle-arrow-right"></i></a>
                            <!--<a href="#" class="theme-btn theme-btn2">Latest Episode<i-->
                            <!--        class="fas fa-circle-arrow-right"></i></a>-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- hero-section end -->


<!-- about area -->
<div class="about-area bg py-80 ">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="about-left wow fadeInLeft" data-wow-delay=".25s">
                    <div class="about-img">
                        <!--<div class="about-experience">-->
                        <!--    <h6>85.6k</h6>-->
                        <!--    <p>Client</p>-->
                        <!--</div>-->
                        <div class="row">
                            <div class="col-6">
                                <div class="img-1">
                                    <img src="img/banner-img6.jpg" alt=""style="height:400px;border-radius:10px;">
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="img-2">
                                    <img src="img/banner-img77.jpg" alt="" style="height:400px;border-radius:10px;">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="about-right wow fadeInRight" data-wow-delay=".25s">
                    <div class="site-heading mb-3">
                        <span class="site-title-tagline"><i class="fas fa-microphone-lines"></i> About Us</span>
                        <h2 class="site-title typing">

                           Jibu Ramachandran –  <span> Audio Lead</span> 
                            <!-- Easy & Quick <span>Way To Listen</span> Favorite Podcast -->
                        </h2>
                    </div>
                    <div class="about-content" >
                        <p class="about-text" style="font-family: 'Poppins', sans-serif;">
                           With over two decades in the professional audio industry,Jibu Ramachandran is widely known for combining technical expertise with practical solutions.His career has spanned roles as an Audio Engineer with Zee TV, full-time Faculty and Chief Audio Engineer at Digital Academy, and later as National Product Manager for Neumann and the Audio Recording segment at Sennheiser India.
                        </p>
                        
                        
                        <div class="about-item-wrap">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="about-item">
                                        <div class="icon">
                                            <img src="assets/img/icon/podcast-1.svg" alt="">
                                        </div>
                                        <div class="content">
                                            <h4>Tailored Audio Solutions</h4>
                                            <p>with end-to-end support, from design to installation.</p>
                                        </div>
                                    </div>
                                    <div class="about-item">
                                        <div class="icon">
                                            <img src="assets/img/icon/podcast.svg" alt="">
                                        </div>
                                        <div class="content">
                                            <h4>Best Sound Quality</h4>
                                            <p>Experience superior sound quality with expert solutions</p>
                                        </div>
                                    </div>
                                </div>
                                  <div class="col-md-6">
                                    <ul class="about-list">
                                                <li class="about-list-item">
                                                    <i class="fas fa-circle-check"></i> Microphones & Speakers
                                                </li>
                                                <li class="about-list-item">
                                                    <i class="fas fa-circle-check"></i> Acoustic Design
                                                </li>
                                                <li class="about-list-item">
                                                    <i class="fas fa-circle-check"></i> Seamless Installation
                                                </li>
                                                <li class="about-list-item">
                                                    <i class="fas fa-circle-check"></i> Ongoing Support
                                                </li>
                                            </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="about-bottom">
                        <a href="about.php" class="theme-btn">Read More<i
                                class="fas fa-circle-arrow-right"></i></a>
                        <div class="about-phone">
                            <div class="icon"><i class="far fa-headset"></i></div>
                            <div class="number">
                                <span>Call Now</span>
                                <h6><a href="tel:+91 9930622006">+91 9930622006</a></h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- about area end -->
    <!-- counter area -->
        <div class="counter-area pt-40 pb-40">
            <div class="container">
                <div class="row wow fadeInUp" data-wow-delay=".25s">
                    <div class="col-lg-3 col-sm-6">
                        <div class="counter-box">
                            <div class="icon">
                                <img src="assets/img/icon/podcast.svg" alt="">
                            </div>
                            <div class="counter-item">
                                <div class="counter-content">
                                    <span class="counter" data-count="+" data-to="200" data-speed="3000">200</span>
                                    <span class="counter-unit">+</span>
                                </div>
                                <h6 class="title">Support Given</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="counter-box">
                            <div class="icon">
                                <img src="assets/img/icon/love.svg" alt="">
                            </div>
                            <div class="counter-item">
                                <div class="counter-content">
                                    <span class="counter" data-count="+" data-to="900" data-speed="3000">900</span>
                                    <span class="counter-unit">+</span>
                                </div>
                                <h6 class="title">Projects Completed</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="counter-box">
                            <div class="icon">
                                <img src="img/award.png" alt="">
                            </div>
                            <div class="counter-item">
                                <div class="counter-content">
                                    <span class="counter" data-count="+" data-to="150" data-speed="3000">150</span>
                                    <span class="counter-unit">+</span>
                                </div>
                                <h6 class="title">Get Awards</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="counter-box">
                            <div class="icon">
                                <img src="img/coffee.png" alt="">
                            </div>
                            <div class="counter-item">
                                <div class="counter-content">
                                    <span class="counter" data-count="+" data-to="30" data-speed="3000">30</span>
                                    <span class="counter-unit">+</span>
                                </div>
                                <h6 class="title">Cups of Coffee</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- counter area end -->

<!-- main-category -->
<div class="main-category bg py-80">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 mx-auto">
                <div class="site-heading-inline wow fadeInDown" data-wow-delay=".25s">
                    <div>
                        <span class="site-title-tagline"><i class="fas fa-microphone-lines"></i> Services</span>
                        <h2 class="typing">Crafting perfect acoustics, <br>every step of the way </h2>
                    </div>
                    </div>
            </div>
        </div>
        <div class="row g-4">
            <div class="col-md-6 col-lg-4 col-xl-4">
                <div class="show-item wow fadeInUp cc" data-wow-delay=".25s">
                    <div class="show-img">
                        <img src="img/banner-img78.jpg" alt="">
                    </div>
                    <div class="show-content ">
                        <h4><a href="#">Acoustic Consultancy</a></h4>
                        <p>We guide you with the technical and commercial aspects in setting up your facility. We help you create a blueprint of your project, plan stages, and finalize vendors.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xl-4">
                <div class="show-item wow fadeInUp cc" data-wow-delay=".25s">
                    <div class="show-img">
                        <img src="img/banner-img79.jpg" alt="" >
                    </div>
                    <div class="show-content">
                        <h4><a href="#">Studio Designing</a></h4>
                        <p>We simulate, analyze, and calculate the acoustic characteristics of your facility to create detailed drawings and design material specifications for your studio.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xl-4">
                <div class="show-item wow fadeInUp cc" data-wow-delay=".25s">
                    <div class="show-img">
                        <img src="img/banner-img80.jpg" alt="">
                    </div>
                    <div class="show-content">
                        <h4><a href="#">System Upgradation</a></h4>
                        <p>If you need to upgrade your studio, we help you with the workflow, product selection, supply, and installation to match your clients' requirements.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xl-4">
                <div class="show-item wow fadeInUp cc" data-wow-delay=".25s">
                    <div class="show-img">
                        <img src="img/banner-img81.jpg" alt="">
                    </div>
                    <div class="show-content">
                        <h4><a href="#">Acoustic Solutions</a></h4>
                        <p>If your studio doesn't sound right, we provide solutions that fix the room's anomalies to achieve the aural experience you are looking for.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xl-4">
                <div class="show-item wow fadeInUp cc" data-wow-delay=".25s">
                    <div class="show-img">
                        <img src="img/banner-img82.jpg" alt="">
                    </div>
                    <div class="show-content">
                        <h4><a href="#">Aesthetics and Lighting Designing</a></h4>
                        <p>Our experts visually elevate your space with the right aesthetics and lighting to set the correct vibe and mood for a creative environment.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xl-4">
                <div class="show-item wow fadeInUp cc" data-wow-delay=".25s">
                    <div class="show-img">
                        <img src="img/banner-img84.jpg" alt="">
                    </div>
                    <div class="show-content">
                        <h4><a href="#">System Designing</a></h4>
                        <p>We design the perfect system for your current and future needs, including a complete list of equipment, cables, software, and plugins.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xl-4">
                <div class="show-item wow fadeInUp cc" data-wow-delay=".25s">
                    <div class="show-img">
                        <img src="img/banner-img85.jpg" alt="">
                    </div>
                    <div class="show-content">
                        <h4><a href="#">System Integration</a></h4>
                        <p>We ensure all equipment and systems are seamlessly brought together to work as a cohesive unit in a professional setup.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xl-4">
                <div class="show-item wow fadeInUp cc" data-wow-delay=".25s">
                    <div class="show-img">
                        <img src="img/banner-img86.jpg" alt="">
                    </div>
                    <div class="show-content">
                        <h4><a href="#">Supply of Materials</a></h4>
                        <p>As key partners for various pro audio brands, we assist with your requirements whether for a complex project or a single product.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xl-4">
                <div class="show-item wow fadeInUp cc" data-wow-delay=".25s">
                    <div class="show-img">
                        <img src="img/banner-img87.jpg" alt="">
                    </div>
                    <div class="show-content">
                        <h4><a href="#">Installation and Cabling</a></h4>
                        <p>We are equipped to install any simple or complex setup, and we design, plan, and execute the cabling as well.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xl-4">
                <div class="show-item wow fadeInUp cc" data-wow-delay=".25s">
                    <div class="show-img">
                        <img src="img/banner-img88.jpg" alt="">
                    </div>
                    <div class="show-content">
                        <h4><a href="#">Calibration</a></h4>
                        <p>We tune and calibrate your systems to comply with relevant international standards, ensuring your professional audio setup is precise.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xl-4">
                <div class="show-item wow fadeInUp cc" data-wow-delay=".25s">
                    <div class="show-img">
                        <img src="img/tech.jpg" alt="" >
                    </div>
                    <div class="show-content">
                        <h4><a href="#">Technical Training</a></h4>
                        <p>We train your team to understand and fluently use the system, ensuring they can work effectively with the rapidly changing technology.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-8 mx-auto">
        </div>
    </div>
</div>
<!-- main-category end -->
<!-- team section start  -->
   <main class="main" style="background: var(--theme-bg-light);">

       
        
        <!-- team-area -->
        <div class="team-area py-100">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 mx-auto">
                        <div class="site-heading text-center wow fadeInDown" data-wow-delay=".25s">
                            <span class="site-title-tagline"><i class="fas fa-microphone-lines"></i> Our Team</span>
                            <h2 class="site-title"> Jibu, Audio & Acoustic Consultant<span></span></h2>
                        </div>
                      
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-lg-4 col-xl-3">
                        <div class="team-item wow fadeInUp" data-wow-delay=".25s">
                            <div class="team-img">
                                <img src="assets/img/team/04.jpg" alt="thumb">
                               
                            </div>
                            <div class="team-info">
                                <h5><a href="#">Amit Bharadwaj </a></h5>
                                <!-- <span>Lead Acoustics and Design</span> -->
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 col-xl-3">
                        <div class="team-item wow fadeInUp" data-wow-delay=".25s">
                            <div class="team-img">
                                <img src="assets/img/team/02.jpg" alt="thumb">
                               
                            </div>
                            <div class="team-info">
                                <h5><a href="#">Frank Mitchell</a></h5>
                                <!-- <span>Senior Host</span> -->
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 col-xl-3">
                        <div class="team-item wow fadeInUp" data-wow-delay=".25s">
                            <div class="team-img">
                                <img src="assets/img/team/03.jpg" alt="thumb">
                               
                            </div>
                            <div class="team-info">
                                <h5><a href="#">Susan Lunsford</a></h5>
                                <!-- <span>CEO & Founder</span> -->
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 col-xl-3">
                        <div class="team-item wow fadeInUp" data-wow-delay=".25s">
                            <div class="team-img">
                                <img src="assets/img/team/04.jpg" alt="thumb">
                               
                            </div>
                            <div class="team-info">
                                <h5><a href="#">Dennis Pruitt</a></h5>
                                <!-- <span>Senior Host</span> -->
                            </div>
                        </div>
                    </div>
                   
                </div>
            </div>
        </div>
        <!-- team-area end -->
<!-- Team Member Bio Section -->
<!-- <section class="py-3" style="background-color: #fff; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;"> -->
  <div class="container py-5" >
    <div class="p-4 shadow-sm rounded" style="border: 1px solid #e0e0e0;">
      <h3 class="fw-bold mb-3 text-primary">Meet Jibu</h3>
      <p style="font-size: 1.05rem; line-height: 1.7; color: white; text-align: justify;">
        Jibu brings over two decades of experience in shaping how spaces sound. 
        From leading Neumann and premium audio at Sennheiser India to consulting for top studios, broadcasters, and artists, 
        he blends technical know-how and creative insight. Trained in speaker calibration in Germany, 
        he now helps transform studios, venues, and homes into exceptional listening environments.
      </p>
    </div>
  </div>
<!-- </section> -->



    </main>

<!-- team section ends  -->
<!-- Dolby Atoms -->
<div class="cta-area">
    <div class="cta-shape">
        <img src="assets/img/shape/06.png" alt="">
    </div>
    <div class="container">
        <div class="cta-wrapper">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="cta-content">
                        <h1 class="wow fadeInUp" data-wow-delay=".25s" style="visibility: visible; animation-delay: 0.25s; animation-name: fadeInUp;">Dolby Atmos</h1>
                        <p class="wow fadeInUp" data-wow-delay=".50s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInUp;">Get a consultation with experts to bring the Dolby Atmos Mastering Suite into your studio.
                            content of a page when looking at its layout.</p>
                        <!-- <a href="#" class="theme-btn wow fadeInUp" data-wow-delay=".75s" style="visibility: visible; animation-delay: 0.75s; animation-name: fadeInUp;">Get Started<i class="fas fa-circle-arrow-right"></i></a> -->
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="cta-img wow fadeInUp" data-wow-delay=".25s" style="visibility: visible; animation-delay: 0.25s; animation-name: fadeInUp;">
                        <div class="cta-img-shape">
                            <!-- <img src="assets/img/shape/05.png" alt=""> -->
                        </div>
                        <img src="assets/img/aa.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End of Dolby Atoms -->
      <!-- partner area -->
        <div class="partner-area bg pt-50 pb-50">
            <div class="container">
                <div class="partner-wrapper">
                    <div class="partner-slider owl-carousel owl-theme wow fadeInUp" data-wow-delay=".25s">
                        <img src="assets/img/partner/01.png" alt="thumb">
                        <img src="assets/img/partner/02.png" alt="thumb">
                        <img src="assets/img/partner/03.png" alt="thumb">
                        <img src="assets/img/partner/04.png" alt="thumb">
                        <img src="assets/img/partner/05.png" alt="thumb">
                        <img src="assets/img/partner/03.png" alt="thumb">
                        <img src="assets/img/partner/02.png" alt="thumb">
                    </div>
                </div>
            </div>
        </div>
        <!-- partner area end -->
   <!-- testimonial area -->
        <div class="testimonial-area bg pt-60 pb-60">
            <div class="testimonial-bg">
                <img src="assets/img/testimonial/bg.jpg" alt="">
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="site-heading wow fadeInDown" data-wow-delay=".25s">
                            <span class="site-title-tagline"><i class="fas fa-microphone-lines"></i> Testimonials</span>
                            <h2 class="site-title">What Our Client Say's</h2>
                        </div>
                    </div>
                </div>
                <div class="col-lg-10 me-auto wow fadeInUp" data-wow-delay=".25s">
                    <div class="testimonial-slider owl-carousel owl-theme">
                        <div class="testimonial-item">
                            <div class="testimonial-rate">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                            </div>
                            <div class="testimonial-quote">
                                <p>
                                Sync Pro Audio is simply outstanding! Their expertise in setting up our DOLBY ATMOS studio and providing audio gears for our multi-channel rooms exceeded all expectations.
                                </p>
                            </div>
                            <div class="testimonial-author">
                                <div class="author-img">
                                    <img src="assets/img/testimonial/01.jpg" alt="">
                                </div>
                                <div class="author-info">
                                    <h4>ABEY DAVID &amp; VINEETH V.E</h4>
                                    <p>AUDIO MATRIX Pvt Ltd</p>
                                </div>
                            </div>
                            <div class="quote-icon">
                                <img src="assets/img/icon/quote.svg" alt="">
                            </div>
                        </div>
                        <div class="testimonial-item">
                            <div class="testimonial-rate">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                            </div>
                            <div class="testimonial-quote">
                                <p>
                                     Jibu being an industry leader (headed Neumann India for many years) has spent hours with me helping me design and find solutions to my setup, expecially on the Dolby front.
                                </p>
                            </div>
                            <div class="testimonial-author">
                                <div class="author-img">
                                    <img src="assets/img/testimonial/02.jpg" alt="">
                                </div>
                                <div class="author-info">
                                    <h4>Mukul Jain</h4>
                                    <p>Ferris wheels studios</p>
                                </div>
                            </div>
                            <div class="quote-icon">
                                <img src="assets/img/icon/quote.svg" alt="">
                            </div>
                        </div>
                        <div class="testimonial-item">
                            <div class="testimonial-rate">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                            </div>
                            <div class="testimonial-quote">
                                <p>
                                    I am delighted to share my experience working with Sync Pro Audio in setting up our 5.1 studio. The level of service and expertise they provided exceeded all our expectations, and I can't recommend them highly enough.
                                </p>
                            </div>
                            <div class="testimonial-author">
                                <div class="author-img">
                                    <img src="assets/img/testimonial/03.jpg" alt="">
                                </div>
                                <div class="author-info">
                                    <h4>Mantra</h4>
                                    <p>Mantramugdh Studio - Mumbai</p>
                                </div>
                            </div>
                            <div class="quote-icon">
                                <img src="assets/img/icon/quote.svg" alt="">
                            </div>
                        </div>
                        <div class="testimonial-item">
                            <div class="testimonial-rate">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                            </div>
                            <div class="testimonial-quote">
                                <p>
                                    There are many variations of passages available but the majority have suffered alteration
                                    in some established fact that the majority have suffered alteration.
                                </p>
                            </div>
                            <div class="testimonial-author">
                                <div class="author-img">
                                    <img src="assets/img/testimonial/04.jpg" alt="">
                                </div>
                                <div class="author-info">
                                    <h4>Edward Miles</h4>
                                    <p>Customer</p>
                                </div>
                            </div>
                            <div class="quote-icon">
                                <img src="assets/img/icon/quote.svg" alt="">
                            </div>
                        </div>
                        <div class="testimonial-item">
                            <div class="testimonial-rate">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                            </div>
                            <div class="testimonial-quote">
                                <p>
                                    There are many variations of passages available but the majority have suffered alteration
                                    in some established fact that the majority have suffered alteration.
                                </p>
                            </div>
                            <div class="testimonial-author">
                                <div class="author-img">
                                    <img src="assets/img/testimonial/05.jpg" alt="">
                                </div>
                                <div class="author-info">
                                    <h4>Ninal Gordon</h4>
                                    <p>Customer</p>
                                </div>
                            </div>
                            <div class="quote-icon">
                                <img src="assets/img/icon/quote.svg" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- testimonial area end -->

        <!-- video-area -->
        <!-- <div class="video-area wow fadeInUp" data-wow-delay=".25s">
            <div class="container">
                <div class="video-content" style="background-image: url(assets/img/video/01.jpg);">
                    <div class="row align-items-center">
                        <div class="col-lg-12">
                            <div class="video-wrapper">
                                <div class="col-lg-6 mx-auto">
                                    <div class="video-info">
                                        <h1 class="video-title">Let's check our latest video</h1>
                                        <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>
                                    </div>
                                </div>
                                <a class="play-btn popup-youtube" href="https://www.youtube.com/watch?v=ckHzmP1evNU">
                                    <i class="fas fa-play"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->
        <!-- video-area end -->


<?php include("footer.php"); ?>