<?php include('header.php'); ?>

<main class="main ">

    <!-- breadcrumb -->
    <div class="site-breadcrumb" style="background: url(assets/img/breadcrumb/01.jpg)">
        <div class="container">
            <h2 class="breadcrumb-title">Equipment Sales & Supply</h2>
            <ul class="breadcrumb-menu">
                <li><a href="index.html">Home</a></li>
                <li class="active">Equipment Sales & Supply</li>
            </ul>
        </div>
    </div>
    <!-- breadcrumb end -->

    <!-- episode-single -->
    <div class="episode-single py-100">
        <div class="container">
            <div class="row">

                <div class="col-lg-8 col-xl-9">
                    <div class="episode-single-content">
                        <div class="episode-single-img">
                            <img src="https://i.pinimg.com/736x/d2/6d/fe/d26dfed495044728bf8adf8c38c105c6.jpg" alt="">
                        </div>
                        <div class="episode-single-info">
                            <h3 class="title">Equipment Sales & Supply</h3>
                            <p class="mb-20">
                                Need just the gear? We’ve got you covered.
                            </p>
                            <p class="mb-20">
                                As channel partners for leading global audio and video brands, we supply everything from
                                speakers, mixers, microphones, and cables to screens, AV receivers, software, and
                                post-production tools. Whether you’re setting up a studio, classroom, or home theatre,
                                we deliver the right products, straight to you.
                            </p>
                            <div class="episode-single-more-img">
                                <div class="row">
                                    <div class="col-md-6 mb-20">
                                        <img src="img/banner-img670.jpg" alt="">
                                    </div>
                                    <div class="col-md-6 mb-20">
                                        <img src="img/banner-img65.jpg" alt="">
                                    </div>
                                </div>
                            </div>
                            <h3 class="title">Wide Product Range</h3>
                            <p class="mb-20">
                                From premium studio gear to classroom AV tools, we cater to a variety of environments
                                with globally trusted brands.
                            </p>
                            <div class="my-4">
                                <div class="mb-3">
                                    <h3 class="mb-3">Brand Partnerships</h3>
                                    <p>We work closely with top international brands to ensure you get authentic,
                                        high-quality products with full warranty and support.</p>
                                </div>
                                <p>🔹 Authentic gear from trusted manufacturers.</p>
                            </div>
                            <div class="my-4">
                                <h3 class="mb-3"> Delivery & Support</h3>
                                <p>We ensure prompt delivery and provide guidance on setup, usage, and maintenance so
                                    you can get the most out of your investment.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-xl-3">
                    <div class="widget">
                        <h4 class="widget-title">Services</h4>
                        <div class="category-list">
                            <a href="Acoustic.php"><i class="far fa-arrow-right"></i>Acoustic Consultancy Service</a>
                            <a href="Seamless.php"><i class="far fa-arrow-right"></i>Seamless System Integration</a>
                            <a href="Dolbyatmos.php"><i class="far fa-arrow-right"></i>Dolby Atmos Consultancy</a>
                            <a href="hometheatres.php"><i class="far fa-arrow-right"></i>Home Theatres</a>
                            <a href="equpment-sale.php"><i class="far fa-arrow-right"></i>Equipment Sales & Supply</a>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- episode-single end -->

    <!-- Key Benefits -->
    <section class="py-5 bg-light">
        <div class="container">
            <h2 class="text-center mb-5 section-heading" style="color:#46b8e9;">Why Buy from Us?</h2>
            <div class="row g-4">

                <!-- Card 1 -->
                <div class="col-md-4">
                    <div class="custom-card text-center p-4 h-100">
                        <div class="icon mb-3">
                            <i class="fas fa-microphone-alt fa-3x text-primary"></i>
                        </div>
                        <h5 class="mb-2">Premium Audio Gear</h5>
                        <p>We supply professional-grade microphones, speakers, and mixers for any application.</p>
                    </div>
                </div>

                <!-- Card 2 -->
                <div class="col-md-4">
                    <div class="custom-card text-center p-4 h-100">
                        <div class="icon mb-3">
                            <i class="fas fa-shipping-fast fa-3x text-success"></i>
                        </div>
                        <h5 class="mb-2">Fast & Reliable Delivery</h5>
                        <p>Quick turnaround times to get your equipment to you when you need it most.</p>
                    </div>
                </div>

                <!-- Card 3 -->
                <div class="col-md-4">
                    <div class="custom-card text-center p-4 h-100">
                        <div class="icon mb-3">
                            <i class="fas fa-tools fa-3x text-danger"></i>
                        </div>
                        <h5 class="mb-2">Setup Assistance</h5>
                        <p>Expert advice and guidance to ensure your gear works perfectly from day one.</p>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- Custom CSS -->
    <style>
    .custom-card {
        background: #fff;
        border-radius: 20px;
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
        transition: all 0.3s ease-in-out;
    }

    .custom-card:hover {
        transform: translateY(-8px);
        box-shadow: 0 12px 25px rgba(0, 0, 0, 0.12);
    }

    .custom-card .icon i {
        transition: color 0.3s ease-in-out;
    }

    .custom-card:hover .icon i {
        color: #46b8e9 !important;
    }

    .section-heading {
        font-size: 2.2rem;
        font-weight: bold;
    }
    </style>

    <style>
    .hover-effect:hover {
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15) !important;
        transform: translateY(-5px);
        transition: all 0.3s ease;
    }
    </style>

</main>

<?php include('footer.php'); ?>