<?php include('header.php'); ?>


<main class="main ">

    <!-- breadcrumb -->
    <div class="site-breadcrumb" style="background: url(assets/img/breadcrumb/01.jpg)">
        <div class="container">
            <h2 class="breadcrumb-title">Home Theatres Service</h2>
            <ul class="breadcrumb-menu">
                <li><a href="index.html">Home</a></li>
                <li class="active">Home Theatres</li>
            </ul>
        </div>
    </div>
    <!-- breadcrumb end -->


    <!-- episode-single -->
    <div class="episode-single py-100">
        <div class="container">
            <div class="row">

                <div class="col-lg-8 col-xl-9">
                    <div class="episode-single-content">
                        <div class="episode-single-img">
                            <img src="img/banner-img24.jpg" alt="">
                        </div>
                        <div class="episode-single-info">
                            <h3 class="title">Customized Home Theatre Design</h3>
                            <p class="mb-20">
                                Transform any space into your personal cinema with bespoke layouts tailored to your room
                                and style.
                                We ensure the perfect balance of aesthetics and functionality.
                            </p>
                            <h3 class="title"> Dolby Atmos Audio Setup</h3>
                            <p class="mb-20">
                                Immerse yourself in rich, 3D audio with professionally calibrated Dolby Atmos systems.
                                Every sound moves around you for a lifelike experience.
                            </p>
                            <div class="episode-single-more-img">
                                <div class="row">
                                    <div class="col-md-6 mb-20">
                                        <img src="img/banner-img23.jpg" alt="">
                                    </div>
                                    <div class="col-md-6 mb-20">
                                        <img src="img/banner-img25.jpg" alt="">
                                    </div>
                                </div>
                            </div>
                            <h3 class="title">Ultra-HD Projection & Display</h3>
                            <p class="mb-20">
                                Enjoy stunning visuals with 4K/8K projectors or large LED displays.
                                We match technology to your room’s lighting and viewing distance.
                            </p>
                            <div class="my-4">
                                <div class="mb-3">
                                    <h3 class="mb-3">Acoustic Treatment Solutions</h3>
                                    <p>Eliminate echoes and enhance clarity with custom acoustic panels.
                                        We create a sound-friendly environment for true audio perfection.</p>
                                </div>
                                <p>🔹 Wall & ceiling panels</p>
                                <p>🔹Noise isolation setups</p>
                                <p>🔹 Echo control engineering</p>
                            </div>
                            <div class="my-4">
                                <h3 class="mb-3"> Smart Home Theatre Controls</h3>
                                <p>Control your entire setup using your smartphone or voice assistant.
                                    Convenience meets technology for a seamless experience.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-xl-3">
                    <div class="widget">
                        <h4 class="widget-title">Services</h4>
                        <div class="category-list">
                            <a href="Acoustic.php"><i class="far fa-arrow-right"></i>Acoustic consultancy Service</a>
                            <a href="Seamless.php"><i class="far fa-arrow-right"></i>Seamless System Integration</a>
                            <a href="Dolbyatmos.php"><i class="far fa-arrow-right"></i>Dolby Atmos consultancy</a>
                            <a href="hometheatres.php"><i class="far fa-arrow-right"></i>Home Theatres</a>
                            <a href="equpment-sale.php"><i class="far fa-arrow-right"></i>Equipment Sales & Supply</a>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- episode-single end -->
    <!-- Home Theatre Solutions Section -->
    <section class="py-5 bg-light">
        <div class="container">
            <h2 class="text-center mb-5 section-heading" style="color:#46b8e9;">Why Choose Our Home Theatre Solutions?
            </h2>
            <div class="row g-4">

                <!-- Card 1 -->
                <div class="col-md-4">
                    <div class="custom-card text-center p-4 h-100">
                        <div class="icon mb-3">
                            <i class="fas fa-tv fa-3x text-primary"></i>
                        </div>
                        <h5 class="mb-2">Cinema-Quality Audio & Visuals</h5>
                        <p>Enjoy immersive sound and crisp visuals with professionally calibrated components.</p>
                    </div>
                </div>

                <!-- Card 2 -->
                <div class="col-md-4">
                    <div class="custom-card text-center p-4 h-100">
                        <div class="icon mb-3">
                            <i class="fas fa-couch fa-3x text-success"></i>
                        </div>
                        <h5 class="mb-2">Tailored Room Design</h5>
                        <p>We design around your space, ensuring optimal screen size, seating, and acoustics.</p>
                    </div>
                </div>

                <!-- Card 3 -->
                <div class="col-md-4">
                    <div class="custom-card text-center p-4 h-100">
                        <div class="icon mb-3">
                            <i class="fas fa-magic fa-3x text-warning"></i>
                        </div>
                        <h5 class="mb-2">Smart Integration</h5>
                        <p>Control your entire system — lighting, AV, curtains — with one remote or mobile app.</p>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- Custom Card Styling -->
    <style>
    .custom-card {
        background-color: #fff;
        border-radius: 20px;
        box-shadow: 0 8px 18px rgba(0, 0, 0, 0.08);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .custom-card:hover {
        transform: translateY(-6px);
        box-shadow: 0 12px 24px rgba(0, 0, 0, 0.15);
    }

    .custom-card .icon i {
        transition: color 0.3s ease;
    }

    .custom-card:hover .icon i {
        color: #46b8e9 !important;
    }

    .section-heading {
        font-size: 2.2rem;
        font-weight: bold;
    }
    </style>



</main>


<?php include('footer.php'); ?>