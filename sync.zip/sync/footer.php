

<!-- Fixed WhatsApp and Call Buttons -->
<style>
.fixed-buttons {
    position: fixed;
    bottom: 20px;
    left: 20px; /* Changed from right: 20px */
    z-index: 9999;
    display: flex;
    flex-direction: column;
    gap: 10px;
}


.fixed-buttons a {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 55px;
    height: 55px;
    border-radius: 50%;
    color: white;
    font-size: 24px;
    text-decoration: none;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    transition: transform 0.3s;
}

.fixed-buttons a:hover {
    transform: scale(1.1);
}

/* WhatsApp */
.fixed-buttons .whatsapp {
    background-color: #25d366;
}

/* Call */
.fixed-buttons .call {
    background-color: #34b7f1;
}
</style>

<!-- Font Awesome CDN (for icons) -->
<!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />-->

<div class="fixed-buttons">
    <!-- WhatsApp Button -->
    <a href="https://wa.me/+919930622006" class="whatsapp" target="_blank">
        <i class="fab fa-whatsapp"></i>
    </a>
    <!-- Call Button -->
    <a href="tel:+91 9930622006" class="call">
        <i class="fas fa-phone"></i>
    </a>
</div>

</main>


<!-- footer area -->
<footer class="footer-area">
    <div class="footer-widget">
        <div class="container">
            <div class="footer-widget-wrapper pt-80 pb-50">
                <div class="row">
                    <div class="col-md-6 col-lg-3">
                        <div class="footer-widget-box about-us">
                            <a href="#" class="footer-logo">
                                <img src="assets/img/foo.png" class="logo-dark-mode" alt="">
                                <img src="assets/img/foo-.png" class="logo-light-mode" alt="">
                            </a>
                            <p class="mb-3" style="font-family: 'Poppins', sans-serif;">
                                Sync Pro Audio delivers turnkey audio solutions and acoustic consultancy for studios, homes, and venues. We supply premium global audio gear with expert installation and support.
                            </p>
                            <ul class="footer-social mt-20">
                                <li><a href="#"><i class="fab fa-square-facebook"></i></a></li>
                                <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                                <li><a href="#"><i class="fab fa-x-twitter"></i></a></li>
                                <li><a href="#"><i class="fab fa-spotify"></i></a></li>
                                <!-- <li><a href="#"><i class="fab fa-tiktok"></i></a></li> -->
                            </ul>
                            <div class="footer-language d-none">
                                <div class="dropdown">
                                    <a href="#" class="language dropdown-toggle" data-bs-toggle="dropdown"
                                        aria-expanded="false">
                                        <img src="assets/img/lang/united-states.png" alt="">
                                        <span>English</span>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li><a class="dropdown-item" href="#"><img
                                                    src="assets/img/lang/united-states.png" alt="">English</a></li>
                                        <li><a class="dropdown-item" href="#"><img src="assets/img/lang/germany.png"
                                                    alt="">Germany</a></li>
                                        <li><a class="dropdown-item" href="#"><img src="assets/img/lang/france.png"
                                                    alt="">France</a></li>
                                        <li><a class="dropdown-item" href="#"><img src="assets/img/lang/china.png"
                                                    alt="">China</a></li>
                                        <li><a class="dropdown-item" href="#"><img src="assets/img/lang/spain.png"
                                                    alt="">Spain</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="footer-widget-box list">
                            <h4 class="footer-widget-title">Useful Links</h4>
                            <ul class="footer-list">
                                <li><a href="index.php">Home</a></li>
                                <li><a href="about.php">About Us</a></li>
                                <li><a href="testimonial.php">Testimonials</a></li>
                                <li><a href="blog.html">Sevices</a></li>
                                <li><a href="contact.php">Contact</a></li>

                            </ul>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="footer-widget-box list">
                            <h4 class="footer-widget-title">Policy</h4>
                            <ul class="footer-list">
                                <li><a href="privacy.html">Privacy policy</a></li>
                                <li><a href="terms.html">Return & Refund Policy</a></li>
                                <li><a href="terms.html">Terms Of Service</a></li>
                                <li><a href="terms.html">Shipping & Delivery</a></li>


                            </ul>
                        </div>
                    </div>
                    <!-- <div class="col-md-6 col-lg-2">
                            <div class="footer-widget-box list">
                                <h4 class="footer-widget-title">Community</h4>
                                <ul class="footer-list">
                                    <li><a href="contact.html">Help Center</a></li>
                                    <li><a href="faq.html">FAQ's</a></li>
                                    <li><a href="contact.html">Contact Us</a></li>
                                    <li><a href="blog.html">Update News</a></li>
                                    <li><a href="donate.html">Donate Us</a></li>
                                    <li><a href="pricing.html">Subscribe Now</a></li>
                                </ul>
                            </div>
                        </div> -->
                    <div class="col-md-6 col-lg-3">
    <div class="footer-widget-box list">
        <h4 class="footer-widget-title">Contact Info</h4>
        <ul class="footer-contact-info list-unstyled text-white">
            <li class="d-flex align-items-start mb-2">
                <i class="fas fa-map-marker-alt me-2 mt-1"></i>
                <span>
                    Sync Pro Audio,<br>
                   Office No. 526, Plot No. 33, Haware Intelligenta, Sector 24, Rainbow Business Park, Opp Mafco Market, Vashi - 400703.
                </span>
            </li>
            <li class="d-flex align-items-center mb-2">
                <i class="fas fa-envelope me-2"></i>
                <a class="text-white" href="mailto:info@syncproaudio.com">info@syncproaudio.com</a>
            </li>
            <li class="d-flex align-items-center">
                <i class="fas fa-phone me-2"></i>
                <a class="text-white" href="tel:+91 9930622006">+91 9930622006</a>
            </li>
        </ul>
    </div>
</div>


                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="copyright">
            <div class="row">
                <div class="col align-self-center">
                    <p class="copyright-text text-center">
                        &copy; Copyright <span id="date"></span> <a href="#"> Sync Pro Audio</a>
                        </a> All Rights Reserved.
                    </p>
                </div>
                <!-- <div class="col-md-6 align-self-center">
                        <ul class="footer-menu">
                            <li><a href="contact.html">Support</a></li>
                            <li><a href="terms.html">Terms Of Services</a></li>
                            <li><a href="privacy.html">Privacy Policy</a></li>
                        </ul>
                    </div> -->
            </div>
        </div>
    </div>
</footer>
<!-- footer area end -->


<!-- main-player -->
<!--<div class="main-player">-->
<!--    <div class="audio-player">-->
<!--        <button type="button" class="audio-player-hide"><i class="far fa-angle-down"></i></button>-->
<!--        <div class="player">-->
<!--            <div class="player-cover-img">-->
<!--                <img data-amplitude-song-info="cover_art_url" src="#" alt="cover">-->
<!--            </div>-->
<!--            <div class="player-content">-->
<!--                <div class="song-meta-data">-->
<!--                    <p data-amplitude-song-info="name" class="song-name"></p>-->
<!--                    <p data-amplitude-song-info="artist" class="song-artist"></p>-->
<!--                </div>-->
<!--                <div class="player-time-progress">-->
<!--                    <div id="progress-container">-->
<!--                        <input type="range" class="amplitude-song-slider">-->
<!--                        <progress id="song-played-progress" class="amplitude-song-played-progress"></progress>-->
<!--                        <progress id="song-buffered-progress" class="amplitude-buffered-progress"-->
<!--                            value="0"></progress>-->
<!--                    </div>-->
<!--                    <div class="time-container">-->
<!--                        <span class="current-time">-->
<!--                            <span class="amplitude-current-minutes"></span>:<span-->
<!--                                class="amplitude-current-seconds"></span>-->
<!--                        </span>-->
<!--                        <div id="player-volume" class="player-volume">-->
<!--                            <span id="amplitude-mute" class="amplitude-mute"><i class="fas fa-volume-up"></i></span>-->
<!--                            <input type="range" id="volume-slider" max="100" class="amplitude-volume-slider">-->
<!--                        </div>-->
<!--                        <span class="duration">-->
<!--                            <span class="amplitude-duration-minutes"></span>:<span-->
<!--                                class="amplitude-duration-seconds"></span>-->
<!--                        </span>-->
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--            <div class="player-controls">-->
<!--                <div class="amplitude-shuffle amplitude-shuffle-off" id="shuffle">-->
<!--                    <i class="far fa-shuffle"></i>-->
<!--                </div>-->
<!--                <div class="amplitude-prev" id="previous">-->
<!--                    <i class="fas fa-backward-step"></i>-->
<!--                </div>-->
<!--                <div class="amplitude-play-pause" id="play-pause">-->
<!--                    <i class="fas fa-play"></i>-->
<!--                </div>-->
<!--                <div class="amplitude-next" id="next">-->
<!--                    <i class="fas fa-forward-step"></i>-->
<!--                </div>-->
<!--                <div class="amplitude-repeat" id="repeat">-->
<!--                    <i class="far fa-repeat"></i>-->
<!--                </div>-->
<!--                <div class="player-playlist show-playlist">-->
<!--                    <i class="far fa-list-music"></i>-->
<!--                </div>-->
<!--            </div>-->
            <!-- playlist-container -->
<!--            <div id="playlist-container">-->
<!--                <div class="playlist-top">-->
<!--                    <h6 class="up-next">Up Next</h6>-->
<!--                    <button type="button" class="close-playlist"><i class="far fa-xmark"></i></button>-->
<!--                </div>-->

                <!-- playlist-item -->
<!--                <div class="playlist-content">-->
<!--                    <div class="playlist-item">-->
<!--                        <div class="playlist-song amplitude-song-container amplitude-play-pause"-->
<!--                            data-amplitude-song-index="0">-->
<!--                            <img src="assets/img/audio/01.jpg" alt="">-->
<!--                            <div class="playlist-song-meta">-->
<!--                                <span class="playlist-song-name">Business Podcast Episode 01</span>-->
<!--                                <span class="playlist-artist-album">Timothy K. Aguilar</span>-->
<!--                            </div>-->
<!--                        </div>-->
<!--                        <button type="button" class="playlist-remove" data-remove-id="d1"><i-->
<!--                                class="far fa-xmark"></i></button>-->
<!--                    </div>-->
<!--                    <div class="playlist-item">-->
<!--                        <div class="playlist-song amplitude-song-container amplitude-play-pause"-->
<!--                            data-amplitude-song-index="1">-->
<!--                            <img src="assets/img/audio/02.jpg" alt="">-->
<!--                            <div class="playlist-song-meta">-->
<!--                                <span class="playlist-song-name">Education Podcast Episode 02</span>-->
<!--                                <span class="playlist-artist-album">Donna C. Nichols</span>-->
<!--                            </div>-->
<!--                        </div>-->
<!--                        <button type="button" class="playlist-remove" data-remove-id="d2"><i-->
<!--                                class="far fa-xmark"></i></button>-->
<!--                    </div>-->

<!--                    <div class="playlist-item">-->
<!--                        <div class="playlist-song amplitude-song-container amplitude-play-pause"-->
<!--                            data-amplitude-song-index="2">-->
<!--                            <img src="assets/img/audio/03.jpg" alt="">-->
<!--                            <div class="playlist-song-meta">-->
<!--                                <span class="playlist-song-name">Business Podcast Episode 03</span>-->
<!--                                <span class="playlist-artist-album">Alvin K. Beveridge</span>-->
<!--                            </div>-->
<!--                        </div>-->
<!--                        <button type="button" class="playlist-remove" data-remove-id="d3"><i-->
<!--                                class="far fa-xmark"></i></button>-->
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
            <!-- playlist-container end -->
<!--        </div>-->
<!--    </div>-->
<!--</div>-->
<!-- main-player end -->

<!-- auto slider script -->
<script>
$(document).ready(function(){
    $(".hero-slider").owlCarousel({
        items: 1,               // one slide at a time
        loop: true,             // infinite loop
        autoplay: true,         // enable auto slide
        autoplayTimeout: 1000,  // slide duration (1 seconds)
        autoplayHoverPause: true, // pause on hover
        animateOut: 'fadeOut',   // fade effect
        animateIn: 'fadeIn',     // fade in effect
        smartSpeed: 1000,        // smooth transition speed
        nav: true,              // show prev/next arrows
        dots: true              // show pagination dots
    });
});
</script>


<!-- scroll-top -->
<div class="scroll-top">
    <a href="#" class="scroll-top-icon"><i class="far fa-arrow-up"></i></a>
    <svg class="scroll-progress-circle" viewBox="0 0 100 100">
        <circle class="scroll-progress-bg" cx="50" cy="50" r="45"></circle>
        <circle class="scroll-progress-bar" cx="50" cy="50" r="45"></circle>
    </svg>
</div>
<!-- scroll-top end -->


<!-- js -->
<script src="assets/js/jquery-3.7.1.min.js"></script>
<script src="assets/js/modernizr.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/imagesloaded.pkgd.min.js"></script>
<script src="assets/js/jquery.magnific-popup.min.js"></script>
<script src="assets/js/isotope.pkgd.min.js"></script>
<script src="assets/js/jquery.appear.min.js"></script>
<script src="assets/js/jquery.easing.min.js"></script>
<script src="assets/js/owl.carousel.min.js"></script>
<script src="assets/js/counter-up.js"></script>
<script src="assets/js/wow.min.js"></script>
<script src="assets/js/jquery.nice-select.min.js"></script>
<script src="assets/js/amplitude.min.js"></script>
<script src="assets/js/amplitude-custom.js"></script>
<script src="assets/js/main.js"></script>

</body>

</html>