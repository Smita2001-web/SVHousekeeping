<?php include("header.php"); ?>
        <!-- breadcrumb -->
        <div class="site-breadcrumb" style="background: url(assets/img/breadcrumb/01.jpg)">
            <div class="container">
                <h2 class="breadcrumb-title">Gallery</h2>
                <ul class="breadcrumb-menu">
                    <li><a href="index.php">Home</a></li>
                    <li class="active">Gallery</li>
                </ul>
            </div>
        </div>
        <!-- breadcrumb end -->

        
        <!-- gallery-area -->
        <div class="gallery-area py-100">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="site-heading text-center wow fadeInDown" data-wow-delay=".25s">
                            <span class="site-title-tagline"><i class="fas fa-microphone-lines"></i> Gallery</span>
                            <h2 class="site-title">Let's Check Our Photo <br> <span>Gallery</span></h2>
                        </div>
                    </div>
                </div>
                <div class="row g-4 popup-gallery">
                    <div class="col-md-6">
                        <div class="gallery-item wow fadeInUp" data-wow-delay=".25s">
                            <div class="gallery-img">
                                <img src="assets/img/gallery/01.jpg" alt="">
                                <a class="popup-img gallery-link" href="assets/img/gallery/01.jpg"><i
                                    class="fal fa-plus"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="gallery-item wow fadeInUp" data-wow-delay=".25s">
                            <div class="gallery-img">
                                <img src="assets/img/gallery/02.jpg" alt="">
                                <a class="popup-img gallery-link" href="assets/img/gallery/02.jpg"><i
                                    class="fal fa-plus"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="gallery-item wow fadeInDown" data-wow-delay=".25s">
                            <div class="gallery-img">
                                <img src="assets/img/gallery/03.jpg" alt="">
                                <a class="popup-img gallery-link" href="assets/img/gallery/03.jpg"><i
                                    class="fal fa-plus"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="gallery-item wow fadeInUp" data-wow-delay=".25s">
                            <div class="gallery-img">
                                <img src="assets/img/gallery/04.jpg" alt="">
                                <a class="popup-img gallery-link" href="assets/img/gallery/04.jpg"><i
                                    class="fal fa-plus"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="gallery-item wow fadeInDown" data-wow-delay=".25s">
                            <div class="gallery-img">
                                <img src="assets/img/gallery/05.jpg" alt="">
                                <a class="popup-img gallery-link" href="assets/img/gallery/05.jpg"><i
                                    class="fal fa-plus"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="gallery-item wow fadeInUp" data-wow-delay=".25s">
                            <div class="gallery-img">
                                <img src="assets/img/gallery/06.jpg" alt="">
                                <a class="popup-img gallery-link" href="assets/img/gallery/06.jpg"><i
                                    class="fal fa-plus"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- gallery-area end -->
<?php include("footer.php"); ?>