<?php include('header.php'); ?>


    <main class="main ">

        <!-- breadcrumb -->
        <div class="site-breadcrumb" style="background: url(assets/img/breadcrumb/01.jpg)">
            <div class="container">
                <h2 class="breadcrumb-title">Acoustic consultancy Service</h2>
                <ul class="breadcrumb-menu">
                    <li><a href="index.html">Home</a></li>
                    <li class="active">Acoustic consultancy</li>
                </ul>
            </div>
        </div>
        <!-- breadcrumb end -->


        <!-- episode-single -->
        <div class="episode-single py-100">
            <div class="container">
                <div class="row">
                   
                    <div class="col-lg-8 col-xl-9">
                        <div class="episode-single-content">
                            <div class="episode-single-img">
                                <img src="img/banner-img56.jpg" alt="">
                            </div>
                            <div class="episode-single-info">
                                <h3 class="title">The way a space sounds changes the way it feels.</h3>
                                <p class="mb-20">
                                We help shape that experience—designing acoustics that make music immersive, dialogues crisp, and silence absolute. Whether it’s a studio, theatre, or live venue, we offer consultancy, isolation solutions, and custom-made panels, with options to execute or just guide you.
                                </p>
                               <h3 class="title">Audio-Visual Design & Integration:</h3>
                                <p class="mb-20">
                            We create complete audio visual ecosystems—perfectly tuned sound, lifelike visuals, and seamless control. From studios, boardrooms, and classrooms to luxury home theatres, we design and integrate everything: speakers, conferencing systems, interactive panels, screens, projectors, recliners, and more. Whether you need a single solution or a full turnkey setup, we make technology work beautifully together.
                                </p>
                                <div class="episode-single-more-img">
                                    <div class="row">
                                        <div class="col-md-6 mb-20">
                                            <img src="img/banner-img57.jpg" alt="">
                                        </div>
                                        <div class="col-md-6 mb-20">
                                            <img src="img/banner-img59.jpg" alt="">
                                        </div>
                                    </div>
                                </div>
                                <h3 class="title">Soundproofing Solutions</h3>
                                <p class="mb-20">
                                 Our team provides tailored soundproofing strategies for walls, ceilings, floors, and partitions. Using advanced materials and construction techniques, we help reduce noise pollution and improve privacy across spaces like studios, conference rooms, and industrial sites.
                                </p>
                              
                                <div class="my-4">
                                    <h3 class="mb-3"> Compliance & Certification Support</h3>
                                    <p>Our consultancy includes support for meeting national and local acoustic compliance standards. We provide reports, documentation, and expert advice to help clients navigate approvals for construction, licensing, or environmental impact assessments.
                                    </p>
                                </div>
                            </div>  
                        </div>
                    </div>
                        <div class="col-lg-4 col-xl-3">
                    <div class="widget">
                        <h4 class="widget-title">Services</h4>
                        <div class="category-list">
                            <a href="Acoustic.php"><i class="far fa-arrow-right"></i>Acoustic consultancy Service</a>
                            <a href="Seamless.php"><i class="far fa-arrow-right"></i>Seamless System Integration</a>
                            <a href="Dolbyatmos.php"><i class="far fa-arrow-right"></i>Dolby Atmos consultancy</a>
                            <a href="hometheatres.php"><i class="far fa-arrow-right"></i>Home Theatres</a>
                                <a href="equpment-sale.php"><i class="far fa-arrow-right"></i>Equipment Sales & Supply</a>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
        <!-- episode-single end -->
<section class="py-5 bg-light">
    <div class="container">
        <h2 class="text-center mb-5 section-heading text-black fw-bold">Why Choose Our Consultancy?</h2>
        <div class="row g-4">
            <!-- Card 1 -->
            <div class="col-md-4">
                <div class="card h-100 shadow-sm border-0 text-center p-4 rounded-4 hover-shadow">
                    <div class="card-body">
                        <div class="icon mb-4 text-primary" style="font-size: 40px;">
                            <i class="fas fa-headphones-alt"></i>
                        </div>
                        <h5 class="card-title fw-semibold">Expert Sound Engineers</h5>
                        <p class="card-text text-muted">Our team brings years of experience in designing high-end acoustic environments across India.</p>
                    </div>
                </div>
            </div>
            <!-- Card 2 -->
            <div class="col-md-4">
                <div class="card h-100 shadow-sm border-0 text-center p-4 rounded-4 hover-shadow">
                    <div class="card-body">
                        <div class="icon mb-4 text-success" style="font-size: 40px;">
                            <i class="fas fa-drafting-compass"></i>
                        </div>
                        <h5 class="card-title fw-semibold">Custom Space Analysis</h5>
                        <p class="card-text text-muted">We tailor every solution to your specific room, use-case, and budget for maximum sonic efficiency.</p>
                    </div>
                </div>
            </div>
            <!-- Card 3 -->
            <div class="col-md-4">
                <div class="card h-100 shadow-sm border-0 text-center p-4 rounded-4 hover-shadow">
                    <div class="card-body">
                        <div class="icon mb-4 text-danger" style="font-size: 40px;">
                            <i class="fas fa-volume-up"></i>
                        </div>
                        <h5 class="card-title fw-semibold">Immersive Audio Ready</h5>
                        <p class="card-text text-muted">We support Dolby Atmos and 3D audio formats for both recording and playback optimization.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Optional CSS for hover shadow -->
<style>
    .hover-shadow:hover {
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15) !important;
        transform: translateY(-5px);
        transition: all 0.3s ease;
    }
</style>

    </main>


    <?php include('footer.php'); ?>