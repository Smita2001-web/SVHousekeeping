   <?php include('header.php'); ?>






    <main class="main">

        <!-- breadcrumb -->
        <div class="site-breadcrumb" style="background: url(assets/img/breadcrumb/01.jpg)">
            <div class="container">
                <h2 class="breadcrumb-title">Testimonials</h2>
                <ul class="breadcrumb-menu">
                    <li><a href="index.php">Home</a></li>
                    <li class="active">Testimonials</li>
                </ul>
            </div>
        </div>
        <!-- breadcrumb end -->


        <!-- testimonial area -->
        <div class="testimonial-area bg py-100">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 mx-auto">
                        <div class="site-heading wow fadeInDown text-center" data-wow-delay=".25s">
                            <span class="site-title-tagline"><i class="fas fa-microphone-lines"></i> Testimonials</span>
                            <h2 class="site-title">What Our Client Say's</h2>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12 wow fadeInUp" data-wow-delay=".25s">
                    <div class="testimonial-slider owl-carousel owl-theme">
                        <div class="testimonial-item">
                            <div class="testimonial-rate">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                            </div>
                            <div class="testimonial-quote">
                                <p>
                                    Sync Pro Audio is simply outstanding! Their expertise in setting up our DOLBY ATMOS studio and providing audio gears for our multi-channel rooms exceeded all expectations. 
                                </p>
                            </div>
                            <div class="testimonial-author">
                                <div class="author-img">
                                    <img src="assets/img/testimonial/01.jpg" alt="">
                                </div>
                                <div class="author-info">
                                    <h4>ABEY DAVID &amp; VINEETH V.E</h4>
                                    <p>AUDIO MATRIX Pvt Ltd</p>
                                </div>
                            </div>
                            <div class="quote-icon">
                                <img src="assets/img/icon/quote.svg" alt="">
                            </div>
                        </div>
                        <div class="testimonial-item">
                            <div class="testimonial-rate">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                            </div>
                            <div class="testimonial-quote">
                                <p>
                                  Jibu being an industry leader (headed Neumann India for many years) has spent hours with me helping me design and find solutions to my setup, expecially on the Dolby front.
                                </p>
                            </div>
                            <div class="testimonial-author">
                                <div class="author-img">
                                    <img src="assets/img/testimonial/02.jpg" alt="">
                                </div>
                                <div class="author-info">
                                    <h4>Mukul Jain</h4>
                                    <p>Ferris wheels studios</p>
                                </div>
                            </div>
                            <div class="quote-icon">
                                <img src="assets/img/icon/quote.svg" alt="">
                            </div>
                        </div>
                        <div class="testimonial-item">
                            <div class="testimonial-rate">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                            </div>
                            <div class="testimonial-quote">
                                <p>
                                   I am delighted to share my experience working with Sync Pro Audio in setting up our 5.1 studio. The level of service and expertise they provided exceeded all our expectations, and I can't recommend them highly enough.
                                </p>
                            </div>
                            <div class="testimonial-author">
                                <div class="author-img">
                                    <img src="assets/img/testimonial/03.jpg" alt="">
                                </div>
                                <div class="author-info">
                                    <h4>Mantra</h4>
                                    <p>Mantramugdh Studio - Mumbai</p>
                                </div>
                            </div>
                            <div class="quote-icon">
                                <img src="assets/img/icon/quote.svg" alt="">
                            </div>
                        </div>
                        <div class="testimonial-item">
                            <div class="testimonial-rate">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                            </div>
                            <div class="testimonial-quote">
                                <p>
                                    There are many variations of passages available but the majority have suffered alteration
                                    in some established fact that the majority have suffered alteration.
                                </p>
                            </div>
                            <div class="testimonial-author">
                                <div class="author-img">
                                    <img src="assets/img/testimonial/04.jpg" alt="">
                                </div>
                                <div class="author-info">
                                    <h4>Edward Miles</h4>
                                    <p>Customer</p>
                                </div>
                            </div>
                            <div class="quote-icon">
                                <img src="assets/img/icon/quote.svg" alt="">
                            </div>
                        </div>
                        <div class="testimonial-item">
                            <div class="testimonial-rate">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                            </div>
                            <div class="testimonial-quote">
                                <p>
                                    There are many variations of passages available but the majority have suffered alteration
                                    in some established fact that the majority have suffered alteration.
                                </p>
                            </div>
                            <div class="testimonial-author">
                                <div class="author-img">
                                    <img src="assets/img/testimonial/05.jpg" alt="">
                                </div>
                                <div class="author-info">
                                    <h4>Ninal Gordon</h4>
                                    <p>Customer</p>
                                </div>
                            </div>
                            <div class="quote-icon">
                                <img src="assets/img/icon/quote.svg" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- testimonial area end -->

    </main>


    <?php include('footer.php'); ?>