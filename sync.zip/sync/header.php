<!DOCTYPE html>
<html lang="en">


<head>
    <!-- meta tags -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="keywords" content="">

    <!-- title -->
    <title>Sync Pro Audio</title>

    <!-- favicon -->
    <link rel="icon" type="image/x-icon" href="assets/img/fav.png">

    <!-- css -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/all-fontawesome.min.css">
    <link rel="stylesheet" href="assets/css/feather.min.css">
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <link rel="stylesheet" href="assets/css/magnific-popup.min.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/nice-select.min.css">
    <link rel="stylesheet" href="assets/css/amplitude.css">
    <link rel="stylesheet" href="assets/css/style.css">
    
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/futura-font@1.0.0/styles.css">


    <!-- auto slider -->
    <!-- Owl Carousel CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">

<!-- jQuery -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<!-- Owl Carousel JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>


 
</head>

<body class="home-3">




    <!-- header area -->
    <header class="header">
        <div class="main-navigation">
            <nav class="navbar navbar-expand-lg">
                <div class="container position-relative">
                    <a class="navbar-brand" href="index.php">
                        <img src="assets/img/logo.jpg" alt="logo">
                    </a>
                    <!-- mobile-menu-right -->
                    <div class="mobile-menu-right">
                        <div class="nav-search-wrap">
                            <div class="search-btn">
                                <button type="button" class="nav-right-link search-box-outer"><i
                                        class="feather-search"></i></button>
                            </div>
                        </div>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                            data-bs-target="#main_nav" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-mobile-icon"><i class="feather-menu"></i></span>
                        </button>
                    </div>
                    <!-- mobile-menu-right end -->
                    <div class="collapse navbar-collapse" id="main_nav">
                        <ul class="navbar-nav" style="display: contents;">
                            <li class="nav-item dropdown">
                                <a class="nav-link " href="index.php">Home</a>

                            </li>
                            <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="service.php" id="navbarDropdown" role="button"
                                    data-bs-toggle="dropdown" aria-expanded="false">
                                    Services
                                </a>
                                <ul class="dropdown-menu fade-down" aria-labelledby="navbarDropdown">
                                    <li><a class="dropdown-item" href="Acoustic.php">Acoustic consultancy
                                            Service</a></li>
                                    <li><a class="dropdown-item" href="Seamless.php">Seamless System
                                            Integration</a></li>
                                    <li><a class="dropdown-item" href="Dolbyatmos.php">Dolby Atmos consultancy</a>
                                    </li>
                                    <li><a class="dropdown-item" href="hometheatres.php">Home Theatres</a></li>
                                    <li><a class="dropdown-item" href="equpment-sale.php">Equipment Sales & Supply</a></li>
                                </ul>
                            </li>

                            <li class="nav-item"><a class="nav-link" href="compny-profile.php">Company Profile</a></li>
                            <li class="nav-item"><a class="nav-link" href="testimonial.php">Client Testimonial</a></li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
    </header>
    <!-- header area end -->