<?php include('header.php'); ?>


<main class="main ">

    <!-- breadcrumb -->
    <div class="site-breadcrumb" style="background: url(assets/img/breadcrumb/01.jpg)">
        <div class="container">
            <h2 class="breadcrumb-title">Seamless System Integration</h2>
            <ul class="breadcrumb-menu">
                <li><a href="index.html">Home</a></li>
                <li class="active">Seamless System</li>
            </ul>
        </div>
    </div>
    <!-- breadcrumb end -->


    <!-- episode-single -->
    <div class="episode-single py-100">
        <div class="container">
            <div class="row">

                <div class="col-lg-8 col-xl-9">
                    <div class="episode-single-content">
                        <div class="episode-single-img">
                            <img src="img/banner-img27.jpg" alt="">
                        </div>
                        <div class="episode-single-info">
                            <h3 class="title">Unified Control Interface</h3>
                            <p class="mb-20">
                                We streamline the user experience by integrating lighting, audio, video, HVAC, and
                                security systems into one central interface.
                            </p>
                            <h3 class="title">Cross-Platform Compatibility</h3>
                            <p class="mb-20">
                                Our integration solutions support a wide range of devices and platforms—whether it's
                                smart home systems, professional AV setups, or enterprise automation.
                            </p>
                            <div class="episode-single-more-img">
                                <div class="row">
                                    <div class="col-md-6 mb-20">
                                        <img src="img/banner-img3.jpg" alt="">
                                    </div>
                                    <div class="col-md-6 mb-20">
                                        <img src="img/banner-img56.jpg" alt="">
                                    </div>
                                </div>
                            </div>
                            <h3 class="title">Remote Monitoring & Access</h3>
                            <p class="mb-20">
                                Through secure cloud connectivity, users can access and manage their systems via
                                smartphones, tablets, or desktops. Real-time alerts, diagnostics, and remote
                                troubleshooting improve system uptime and user confidence.
                            </p>
                            <div class="my-4">
                                <div class="mb-3">
                                    <h3 class="mb-3"> Future-Proof Scalability</h3>
                                    <p>Our modular integration architecture allows for future expansion without
                                        overhauling your existing setup. Whether you're adding more rooms, new
                                        technologies, or advanced functionalities, your system remains flexible and
                                        upgradable.</p>
                                </div>
                                <p>🔹 Easily expand as your needs grow.</p>
                            </div>
                            <div class="my-4">
                                <h3 class="mb-3"> Professional Installation & Support</h3>
                                <p>From initial planning to post-installation maintenance, our team ensures every
                                    component is installed correctly, calibrated, and tested for optimal performance. We
                                    also offer on-call support and training to keep your systems running smoothly.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-xl-3">
                    <div class="widget">
                        <h4 class="widget-title">Services</h4>
                        <div class="category-list">
                            <a href="Acoustic.php"><i class="far fa-arrow-right"></i>Acoustic consultancy Service</a>
                            <a href="Seamless.php"><i class="far fa-arrow-right"></i>Seamless System Integration</a>
                            <a href="Dolbyatmos.php"><i class="far fa-arrow-right"></i>Dolby Atmos consultancy</a>
                            <a href="hometheatres.php"><i class="far fa-arrow-right"></i>Home Theatres</a>
                            <a href="equpment-sale.php"><i class="far fa-arrow-right"></i>Equipment Sales & Supply</a>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- episode-single end -->
    <!-- Key Benefits -->
    <section class="py-5 bg-light">
        <div class="container">
            <h2 class="text-center mb-5 section-heading fw-bold" style="color:#46b8e9;">Why Choose Our Integration
                Services?</h2>
            <div class="row g-4">

                <!-- Card 1 -->
                <div class="col-md-4">
                    <div class="card h-100 border-0 shadow-sm text-center p-4 rounded-4 hover-effect">
                        <div class="card-body">
                            <div class="icon mb-4 text-primary" style="font-size: 40px;">
                                <i class="fas fa-network-wired"></i>
                            </div>
                            <h5 class="card-title fw-semibold">Unified Connectivity</h5>
                            <p class="card-text text-muted">All your systems—audio, video, security, lighting—working
                                together seamlessly under one interface.</p>
                        </div>
                    </div>
                </div>

                <!-- Card 2 -->
                <div class="col-md-4">
                    <div class="card h-100 border-0 shadow-sm text-center p-4 rounded-4 hover-effect">
                        <div class="card-body">
                            <div class="icon mb-4 text-success" style="font-size: 40px;">
                                <i class="fas fa-cogs"></i>
                            </div>
                            <h5 class="card-title fw-semibold">Custom Engineered Systems</h5>
                            <p class="card-text text-muted">We design solutions that adapt to your specific space,
                                workflows, and technical infrastructure.</p>
                        </div>
                    </div>
                </div>

                <!-- Card 3 -->
                <div class="col-md-4">
                    <div class="card h-100 border-0 shadow-sm text-center p-4 rounded-4 hover-effect">
                        <div class="card-body">
                            <div class="icon mb-4 text-danger" style="font-size: 40px;">
                                <i class="fas fa-shield-alt"></i>
                            </div>
                            <h5 class="card-title fw-semibold">Security & Reliability</h5>
                            <p class="card-text text-muted">Robust systems built with security, redundancy, and
                                long-term performance in mind.</p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- Optional CSS -->
    <style>
    .hover-effect:hover {
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15) !important;
        transform: translateY(-5px);
        transition: all 0.3s ease;
    }
    </style>


</main>


<?php include('footer.php'); ?>