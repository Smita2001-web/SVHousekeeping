<?php include("header.php"); ?>
<!-- breadcrumb -->
<div class="site-breadcrumb" style="background: url(assets/img/breadcrumb/01.jpg)">
    <div class="container">
        <h2 class="breadcrumb-title">About Us</h2>
        <ul class="breadcrumb-menu">
            <li><a href="index.php">Home</a></li>
            <li class="active">About Us</li>
        </ul>
    </div>
</div>
<!-- breadcrumb end -->


<!-- about area -->
<div class="about-area py-80 mb-20">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="about-left wow fadeInLeft" data-wow-delay=".25s">
                    <div class="about-img">
                        <div class="about-experience">
                            <h6>85.6k</h6>
                            <p>Listeners</p>
                        </div>
                        <div class="row">
                            <div class="col-6">
                                <div class="img-1">
                                    <img src="assets/img/about/01.jpg" alt="">
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="img-2">
                                    <img src="assets/img/about/02.jpg" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="about-right wow fadeInRight" data-wow-delay=".25s">
                    <div class="site-heading mb-3">
                        <span class="site-title-tagline"><i class="fas fa-microphone-lines"></i> About Us</span>
                        <h2 class="site-title">
                            Jibu Ramachandran <span> Audio Lead</span>
                            <!--Easy & Quick <span>Way To Listen</span> Favorite Podcast-->
                        </h2>
                    </div>
                    <div class="about-content">
                        <p class="about-text">
                            With over two decades in the professional audio industry, Jibu Ramachandran is
                                widely known for combining technical expertise with practical solutions. His
                            career has spanned roles as an Audio Engineer with Zee TV, full-time Faculty and Chief Audio
                            Engineer at Digital Academy, and later as  National Product Manager for Neumann and
                                the Audio Recording segment at Sennheiser India.
                        </p>
                        <div class="about-item-wrap">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="about-item">
                                        <div class="icon">
                                            <img src="assets/img/icon/podcast-1.svg" alt="">
                                        </div>
                                        <div class="content">
                                            <h4>Tailored Audio Solutions</h4>
                                            <p>with end-to-end support, from design to installation.</p>
                                        </div>
                                    </div>
                                    <div class="about-item">
                                        <div class="icon">
                                            <img src="assets/img/icon/podcast.svg" alt="">
                                        </div>
                                        <div class="content">
                                            <h4>Best Sound Quality</h4>
                                            <p>Humour random words which look even content layout.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <ul class="about-list">
                                        <li class="about-list-item">
                                            <i class="fas fa-circle-check"></i> Microphones & Speakers
                                        </li>
                                        <li class="about-list-item">
                                            <i class="fas fa-circle-check"></i> Acoustic Design
                                        </li>
                                        <li class="about-list-item">
                                            <i class="fas fa-circle-check"></i> Seamless Installation
                                        </li>
                                        <li class="about-list-item">
                                            <i class="fas fa-circle-check"></i> Ongoing Support
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="about-bottom">
                        <!--<a href="about.html" class="theme-btn">Discover More<i-->
                        <!--        class="fas fa-circle-arrow-right"></i></a>-->
                        <div class="about-phone">
                            <div class="icon"><i class="far fa-headset"></i></div>
                            <div class="number">
                                <span>Call Now</span>
                                <h6><a href="tel:+91 9930622006">+91 9930622006</a></h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- about area end -->
<section class="bio-section text-white py-5">
    <div class="container">
        <div class="bio-content p-4 rounded-4 shadow-lg">
            <p class="mb-3">
                At Sennheiser, he played a pivotal role in building the Neumann brand in India,
                expanding it from a single, niche product to a full range of microphones and monitors that are now
                industry standards. Beyond product management, Jibu provided  studio solutions, troubleshooting,
                    and precision speaker calibrations — a skill he was formally trained for in Germany.
            </p>
            <p class="mb-3">
                He has worked with  Yash Raj Films, AR Rehman Studios, broadcasters like Zee TV, Star TV, Sony
                    TV, Asianet, and institutions such as FTII for their audio needs, and has catered to the
                professional audio requirements of leading artists — to name a few: Sunidhi Chauhan,
                    Salim-Suleiman, Arijit Singh, Hariharan, Shankar–Ehsaan–Loy and Vishal–Shekhar.
            </p>
            <p>
                 Today, Jibu continues to consult on studios, Dolby Atmos, broadcast facilities, venues, places
                    of worship, corporate spaces, and luxury home theatres — with one simple focus: to make every space
                    sound its absolute best.
            </p>
        </div>
    </div>
</section>
<section class="mission-vision-split py-5">
  <div class="container">

    <!-- Mission -->
    <div class="row align-items-center mb-5">
      <div class="col-lg-6">
        <h2 class="fw-bold  mb-3" style="color:#12a6e9;">Mission</h2>
        <p class="lead">
          We help bring your space to life with sound. From studios to auditoriums, houses of worship to home theatres — 
          we design, supply, and install world-class audio and acoustic solutions tailored to your needs.
        </p>
      </div>
      <div class="col-lg-6">
        <img src="https://i.pinimg.com/736x/f7/b5/6a/f7b56a678d429a5a3b4e83b705f97237.jpg" alt="Mission" class="img-fluid rounded-4 shadow-lg">
      </div>
    </div>

    <!-- Vision -->
    <div class="row align-items-center flex-lg-row-reverse">
      <div class="col-lg-6">
        <h2 class="fw-bold  mb-3" style="color:#12a6e9;">Vision</h2>
        <p class="lead">
          To make great sound accessible in every space, creating immersive audio environments that inspire, perform, 
          transform and enrich everyday experiences.
        </p>
      </div>
      <div class="col-lg-6">
        <img src="https://i.pinimg.com/736x/13/9c/84/139c84e4c8c2a45562a513baf4388df6.jpg" alt="Vision" class="img-fluid rounded-4 shadow-lg">
      </div>
    </div>

  </div>
</section>

<style>
  .text-gradient {
    background: linear-gradient(90deg, #ff7e5f, #feb47b);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
  }

  .mission-vision-split p {
    font-size: 1.1rem;
    line-height: 1.7;
    text-align: justify;
  }
</style>




<style>
.bio-section {
    background: linear-gradient(135deg, #1e3c72, #2a5298);
}

.bio-content {
    background: rgba(255, 255, 255, 0.08);
    backdrop-filter: blur(8px);
    border: 1px solid rgba(255, 255, 255, 0.15);
    font-size: 1.1rem;
    line-height: 1.9;

}

.bio-content p {
    text-align: justify;
    letter-spacing: 0.1em;
}
</style>


<!-- counter area -->
<div class="counter-area pt-40 pb-40 mt-5">
    <div class="container">
        <div class="row wow fadeInUp" data-wow-delay=".25s">
            <div class="col-lg-3 col-sm-6">
                <div class="counter-box">
                    <div class="icon">
                        <img src="assets/img/icon/podcast.svg" alt="">
                    </div>
                    <div class="counter-item">
                        <div class="counter-content">
                            <span class="counter" data-count="+" data-to="80" data-speed="3000">80</span>
                            <span class="counter-unit">k</span>
                        </div>
                        <h6 class="title">Support Given</h6>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="counter-box">
                    <div class="icon">
                        <img src="assets/img/icon/love.svg" alt="">
                    </div>
                    <div class="counter-item">
                        <div class="counter-content">
                            <span class="counter" data-count="+" data-to="900" data-speed="3000">900</span>
                            <span class="counter-unit">k</span>
                        </div>
                        <h6 class="title">Projects Completed</h6>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="counter-box">
                    <div class="icon">
                        <img src="img/award.png" alt="">
                    </div>
                    <div class="counter-item">
                        <div class="counter-content">
                            <span class="counter" data-count="+" data-to="150" data-speed="3000">150</span>
                            <span class="counter-unit">+</span>
                        </div>
                        <h6 class="title">Get Awards</h6>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="counter-box">
                    <div class="icon">
                        <img src="img/coffee.png" alt="">
                    </div>
                    <div class="counter-item">
                        <div class="counter-content">
                            <span class="counter" data-count="+" data-to="30" data-speed="3000">30</span>
                            <span class="counter-unit">+</span>
                        </div>
                        <h6 class="title">Cups of Coffee</h6>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- counter area end -->


<!-- choose-area -->
<div class="choose-area py-100">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="choose-content wow fadeInUp" data-wow-delay=".25s">
                    <div class="site-heading mb-3">
                        <span class="site-title-tagline"><i class="fas fa-microphone-lines"></i> Why Choose Us</span>
                        <h2 class="site-title">
                            Experience <span>Exceptional</span> Audio
                        </h2>
                    </div>
                    <p>
                        At Sync Pro Audio, we bring professional-grade audio experiences to your fingertips. Whether
                        you're tuning in on the go, setting up a podcast, or upgrading your studio, we deliver clarity,
                        convenience, and customization in every solution.
                    </p>
                    <div class="choose-item-wrap">
                        <div class="choose-item">
                            <div class="icon">
                                <img src="assets/img/icon/offline.svg" alt="">
                            </div>
                            <div class="content">
                                <h5>Tailored Audio Solutions</h5>
                                <p>It is a long established fact that a reader will be distracted by the readable
                                    content of a page when looking at its layout.</p>
                            </div>
                        </div>
                        <div class="choose-item">
                            <div class="icon">
                                <img src="assets/img/icon/podcast-1.svg" alt="">
                            </div>
                            <div class="content">
                                <h5>All Time Best Sound Quality</h5>
                                <p>Experience superior sound quality with expert solutions and complete support, from
                                    acoustic design to flawless delivery.</p>
                            </div>
                        </div>
                    </div>
                    <!--<div class="mt-40">-->
                    <!--    <a href="#" class="theme-btn">Start Listening<i class="fas fa-circle-arrow-right"></i></a>-->
                    <!--</div>-->
                </div>
            </div>
            <div class="col-lg-6">
                <div class="choose-img-wrap">
                    <div class="choose-img wow fadeInRight" data-wow-delay=".25s">
                        <img src="assets/img/choose/01.jpg" alt="">
                    </div>
                    <div class="choose-img-shape">
                        <img src="assets/img/shape/03.png" alt="">
                    </div>
                    <div class="choose-img-content wow fadeInUp d-none" data-wow-delay=".50s">
                        <ul>
                            <li><i class="fas fa-check-circle"></i> Available On All Platform</li>
                            <li><i class="fas fa-check-circle"></i> Record Your Episodes</li>
                            <li><i class="fas fa-check-circle"></i> Have a Discuss with People</li>
                            <li><i class="fas fa-check-circle"></i> Listen in Screen off Position</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- choose-area end -->


<!-- testimonial area -->
<!--<div class="testimonial-area bg pt-60 pb-60">-->
<!--    <div class="testimonial-bg">-->
<!--        <img src="assets/img/testimonial/bg.jpg" alt="">-->
<!--    </div>-->
<!--    <div class="container">-->
<!--        <div class="row">-->
<!--            <div class="col-lg-6">-->
<!--                <div class="site-heading wow fadeInDown" data-wow-delay=".25s">-->
<!--                    <span class="site-title-tagline"><i class="fas fa-microphone-lines"></i> Testimonials</span>-->
<!--                    <h2 class="site-title">What Our Client Say's</h2>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--        <div class="col-lg-10 me-auto wow fadeInUp" data-wow-delay=".25s">-->
<!--            <div class="testimonial-slider owl-carousel owl-theme">-->
<!--                <div class="testimonial-item">-->
<!--                    <div class="testimonial-rate">-->
<!--                        <i class="fas fa-star"></i>-->
<!--                        <i class="fas fa-star"></i>-->
<!--                        <i class="fas fa-star"></i>-->
<!--                        <i class="fas fa-star"></i>-->
<!--                        <i class="fas fa-star"></i>-->
<!--                    </div>-->
<!--                    <div class="testimonial-quote">-->
<!--                        <p>-->
<!--                            There are many variations of passages available but the majority have suffered alteration-->
<!--                            in some established fact that the majority have suffered alteration.-->
<!--                        </p>-->
<!--                    </div>-->
<!--                    <div class="testimonial-author">-->
<!--                        <div class="author-img">-->
<!--                            <img src="assets/img/testimonial/01.jpg" alt="">-->
<!--                        </div>-->
<!--                        <div class="author-info">-->
<!--                            <h4>Anthony Nicoll</h4>-->
<!--                            <p>Customer</p>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                    <div class="quote-icon">-->
<!--                        <img src="assets/img/icon/quote.svg" alt="">-->
<!--                    </div>-->
<!--                </div>-->
<!--                <div class="testimonial-item">-->
<!--                    <div class="testimonial-rate">-->
<!--                        <i class="fas fa-star"></i>-->
<!--                        <i class="fas fa-star"></i>-->
<!--                        <i class="fas fa-star"></i>-->
<!--                        <i class="fas fa-star"></i>-->
<!--                        <i class="fas fa-star"></i>-->
<!--                    </div>-->
<!--                    <div class="testimonial-quote">-->
<!--                        <p>-->
<!--                            There are many variations of passages available but the majority have suffered alteration-->
<!--                            in some established fact that the majority have suffered alteration.-->
<!--                        </p>-->
<!--                    </div>-->
<!--                    <div class="testimonial-author">-->
<!--                        <div class="author-img">-->
<!--                            <img src="assets/img/testimonial/02.jpg" alt="">-->
<!--                        </div>-->
<!--                        <div class="author-info">-->
<!--                            <h4>Richard Lock</h4>-->
<!--                            <p>Customer</p>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                    <div class="quote-icon">-->
<!--                        <img src="assets/img/icon/quote.svg" alt="">-->
<!--                    </div>-->
<!--                </div>-->
<!--                <div class="testimonial-item">-->
<!--                    <div class="testimonial-rate">-->
<!--                        <i class="fas fa-star"></i>-->
<!--                        <i class="fas fa-star"></i>-->
<!--                        <i class="fas fa-star"></i>-->
<!--                        <i class="fas fa-star"></i>-->
<!--                        <i class="fas fa-star"></i>-->
<!--                    </div>-->
<!--                    <div class="testimonial-quote">-->
<!--                        <p>-->
<!--                            There are many variations of passages available but the majority have suffered alteration-->
<!--                            in some established fact that the majority have suffered alteration.-->
<!--                        </p>-->
<!--                    </div>-->
<!--                    <div class="testimonial-author">-->
<!--                        <div class="author-img">-->
<!--                            <img src="assets/img/testimonial/03.jpg" alt="">-->
<!--                        </div>-->
<!--                        <div class="author-info">-->
<!--                            <h4>Randal Grand</h4>-->
<!--                            <p>Customer</p>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                    <div class="quote-icon">-->
<!--                        <img src="assets/img/icon/quote.svg" alt="">-->
<!--                    </div>-->
<!--                </div>-->
<!--                <div class="testimonial-item">-->
<!--                    <div class="testimonial-rate">-->
<!--                        <i class="fas fa-star"></i>-->
<!--                        <i class="fas fa-star"></i>-->
<!--                        <i class="fas fa-star"></i>-->
<!--                        <i class="fas fa-star"></i>-->
<!--                        <i class="fas fa-star"></i>-->
<!--                    </div>-->
<!--                    <div class="testimonial-quote">-->
<!--                        <p>-->
<!--                            There are many variations of passages available but the majority have suffered alteration-->
<!--                            in some established fact that the majority have suffered alteration.-->
<!--                        </p>-->
<!--                    </div>-->
<!--                    <div class="testimonial-author">-->
<!--                        <div class="author-img">-->
<!--                            <img src="assets/img/testimonial/04.jpg" alt="">-->
<!--                        </div>-->
<!--                        <div class="author-info">-->
<!--                            <h4>Edward Miles</h4>-->
<!--                            <p>Customer</p>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                    <div class="quote-icon">-->
<!--                        <img src="assets/img/icon/quote.svg" alt="">-->
<!--                    </div>-->
<!--                </div>-->
<!--                <div class="testimonial-item">-->
<!--                    <div class="testimonial-rate">-->
<!--                        <i class="fas fa-star"></i>-->
<!--                        <i class="fas fa-star"></i>-->
<!--                        <i class="fas fa-star"></i>-->
<!--                        <i class="fas fa-star"></i>-->
<!--                        <i class="fas fa-star"></i>-->
<!--                    </div>-->
<!--                    <div class="testimonial-quote">-->
<!--                        <p>-->
<!--                            There are many variations of passages available but the majority have suffered alteration-->
<!--                            in some established fact that the majority have suffered alteration.-->
<!--                        </p>-->
<!--                    </div>-->
<!--                    <div class="testimonial-author">-->
<!--                        <div class="author-img">-->
<!--                            <img src="assets/img/testimonial/05.jpg" alt="">-->
<!--                        </div>-->
<!--                        <div class="author-info">-->
<!--                            <h4>Ninal Gordon</h4>-->
<!--                            <p>Customer</p>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                    <div class="quote-icon">-->
<!--                        <img src="assets/img/icon/quote.svg" alt="">-->
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->

<!--    </div>-->
<!--</div>-->
<!-- testimonial area end -->





<!-- partner area -->
<div class="partner-area bg pt-50 pb-50">
    <div class="container">
        <div class="partner-wrapper">
            <div class="partner-slider owl-carousel owl-theme wow fadeInUp" data-wow-delay=".25s">
                <img src="assets/img/partner/01.png" alt="thumb">
                <img src="assets/img/partner/02.png" alt="thumb">
                <img src="assets/img/partner/03.png" alt="thumb">
                <img src="assets/img/partner/04.png" alt="thumb">
                <img src="assets/img/partner/05.png" alt="thumb">
                <img src="assets/img/partner/03.png" alt="thumb">
                <img src="assets/img/partner/02.png" alt="thumb">
            </div>
        </div>
    </div>
</div>
<!-- partner area end -->
<?php include("footer.php"); ?>