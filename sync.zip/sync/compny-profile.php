<?php include('header.php'); ?>







<main class="main">

    <!-- breadcrumb -->
    <div class="site-breadcrumb" style="background: url(assets/img/breadcrumb/01.jpg)">
        <div class="container">
            <h2 class="breadcrumb-title">Company Profile</h2>
            <ul class="breadcrumb-menu">
                <li><a href="index.html">Home</a></li>
                <li class="active">Company Profile</li>
            </ul>
        </div>
    </div>
    <!-- breadcrumb end -->


    <!-- blog single -->
    <div class="blog-single py-80">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="blog-single-wrapper">
                        <div class="blog-single-content">
                            <div class="blog-thumb-img">
                                <img src="assets/img/blog/single.jpg" alt="thumb">
                            </div>
                            <div class="blog-single-info">

                                <div class="blog-details">
                                    <h3 class="blog-details-title mb-20">Transforming Spaces with World-Class Audio
                                        Solutions</h3>
                                    <p class="mb-10">
                                        At Sync Pro Audio we transform ordinary rooms into extraordinary sound spaces.
                                        From world-class recording studios and broadcast facilities to awe-inspiring
                                        auditoriums, places of worship, corporate boardrooms, and private luxury home
                                        theatres, we deliver turnkey professional audio solutions that blend technology,
                                        design, and precision.

                                    </p>
                                    <p class="mb-10">
                                        We handle everything — acoustic and isolation design, equipment planning,
                                        workflow engineering, cabling, HVAC and interiors, installation, tuning, and
                                        team training.
                                        As Dolby Atmos consultants, we create studios that meet international standards,
                                        enabling creators to work with leading OTT platforms.

                                    </p>

                                    <p class="mb-20">
                                        Being channel partners for global audio and video brands, we also supply and
                                        integrate premium microphones, speakers, software, and conferencing solutions.
                                    </p>

                                    <div class="row">
                                        <div class="col-md-6 mb-20">
                                            <img src="assets/img/blog/01.jpg" alt="">
                                        </div>
                                        <div class="col-md-6 mb-20">
                                            <img src="assets/img/blog/02.jpg" alt="">
                                        </div>
                                    </div>
                                    <p class="mb-20">Whether it’s a studio, a hall, a corporate space, or a private
                                        cinema, we design spaces that sound as exceptional as they look — end to end,
                                        with no compromises.</p>
                                    <!-- <h3>Tech Forward / Modern Tone</h3>
                                    <p class="mb-20">
                                        We are specialists in end to end audio and AV innovation.
                                        Whether it’s a studio, auditorium, classroom, or private cinema, we handle
                                        everything — acoustic design, sound isolation, workflow planning, interactive
                                        panels, conferencing systems, Dolby Atmos consulting, equipment supply,
                                        installation, calibration, and training.
                                        Our mission: seamless technology, flawless sound, and future ready spaces

                                    </p> -->
                                    <hr>

                                </div>

                            </div>

                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <aside class="sidebar">
                        <!-- search-->

                        <!-- category -->
                        <div class="widget category">
                            <h5 class="widget-title">Services</h5>
                            <div class="category-list">
                                <a href="Acoustic.php"><i class="far fa-arrow-right"></i>Acoustic consultancy </a>
                                <a href="Seamless.php"><i class="far fa-arrow-right"></i>Seamless System Integration</a>
                                <a href="Dolbyatmos.php"><i class="far fa-arrow-right"></i>Dolby Atmos consultancy</a>
                                <a href="hometheatres.php"><i class="far fa-arrow-right"></i>Home Theatres</a>
                                <a href="equpment-sale.php"><i class="far fa-arrow-right"></i>Equipment Sales & Supply</a>
                            </div>
                        </div>
                        <!-- recent post -->
                     <!-- Calibration & Integration Section Start -->
<section class="calibration-integration py-5 bg-light">
    <div class="container">
        <div class="row align-items-center">
            <!-- Text -->
            <div class="col-md-12">
                 <img src="https://i.pinimg.com/736x/11/2d/ad/112dadf2aceae2213390429d5c07b0f9.jpg" alt="Calibration & Integration" class="img-fluid rounded shadow">
                <h2 class="fw-bold mb-4">Calibration &amp; Integration</h2>
                <p>
                 From equipment setup, cable laying, and custom connectors to workflow design, signal routing, software configuration, and precise calibration—we integrate every component into a seamless, reliable system that’s ready to perform.
                </p>
             
            </div>
            <!-- Image -->
           
        </div>
    </div>
</section>
<!-- Calibration & Integration Section End -->

                        <!-- social share -->
                        <div class="widget social-share">
                            <h5 class="widget-title">Follow Us</h5>
                            <div class="social-share-link">
                                <a href="#"><i class="fab fa-facebook-f"></i></a>
                                <a href="#"><i class="fab fa-x-twitter"></i></a>
                                <a href="#"><i class="fab fa-dribbble"></i></a>
                                <a href="#"><i class="fab fa-whatsapp"></i></a>
                                <a href="#"><i class="fab fa-youtube"></i></a>
                            </div>
                        </div>
                        <!-- recent post -->

                    </aside>
                </div>
            </div>
        </div>
    </div>
    <!-- blog single end -->

</main>

<?php include('footer.php'); ?>