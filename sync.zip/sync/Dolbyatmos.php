<?php include('header.php'); ?>


<main class="main ">

    <!-- breadcrumb -->
    <div class="site-breadcrumb" style="background: url(assets/img/breadcrumb/01.jpg)">
        <div class="container">
            <h2 class="breadcrumb-title">Dolby Atmos consultancy</h2>
            <ul class="breadcrumb-menu">
                <li><a href="index.html">Home</a></li>
                <li class="active">Dolby Atmos consultancy</li>
            </ul>
        </div>
    </div>
    <!-- breadcrumb end -->


    <!-- episode-single -->
    <div class="episode-single py-100">
        <div class="container">
            <div class="row">

                <div class="col-lg-8 col-xl-9">
                    <div class="episode-single-content">
                        <div class="episode-single-img">
                            <img src="img/banner-img60.jpg" alt="">
                        </div>
                        <div class="episode-single-info">
                            <h3 class="title">Dolby Atmos Consultancy:</h3>
                            <p class="mb-20">
                                For studio aiming to work with the world’s top OTT platforms, Dolby Atmos isn’t
                                optional—it’s essential.
                            </p>
                            <h3 class="title"></h3>
                            <p class="mb-20">
                                From room dimensions and acoustic design to equipment selection, speaker placement, and
                                final calibration, our consultancy ensures your studio is Dolby approved and ready for
                                Netflix, Amazon, Hotstaretc..
                            </p>
                            <div class="episode-single-more-img">
                                <div class="row">
                                    <div class="col-md-6 mb-20">
                                        <img src="img/banner-img670.jpg" alt="">
                                    </div>
                                    <div class="col-md-6 mb-20">
                                        <img src="img/banner-img65.jpg" alt="">
                                    </div>
                                </div>
                            </div>
                            <h3 class="title">Studio Certification & Compliance</h3>
                            <p class="mb-20">
                                For post-production houses and music studios, we help configure your setup to meet Dolby
                                Atmos certification standards.
                            </p>
                            <div class="my-4">
                                <div class="mb-3">
                                    <h3 class="mb-3">Training & Support</h3>
                                    <p>We provide on-site and remote training on how to operate and maintain your Atmos
                                        system. This includes usage of software interfaces, mixing workflows, and
                                        troubleshooting, ensuring you’re equipped to deliver premium spatial audio
                                        experiences.</p>
                                </div>
                                <p>🔹 Hands-on training for engineers and users.</p>
                            </div>
                            <div class="my-4">
                                <h3 class="mb-3"> Professional Calibration & Tuning</h3>
                                <p>We perform detailed system calibration using professional tools like Dirac Live or
                                    Audyssey, ensuring every sound object moves naturally in the room. Proper tuning
                                    maximizes the impact of Dolby Atmos and enhances audio clarity.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-xl-3">
                    <div class="widget">
                        <h4 class="widget-title">Services</h4>
                        <div class="category-list">
                            <a href="Acoustic.php"><i class="far fa-arrow-right"></i>Acoustic consultancy Service</a>
                            <a href="Seamless.php"><i class="far fa-arrow-right"></i>Seamless System Integration</a>
                            <a href="Dolbyatmos.php"><i class="far fa-arrow-right"></i>Dolby Atmos consultancy</a>
                            <a href="hometheatres.php"><i class="far fa-arrow-right"></i>Home Theatres</a>
                            <a href="equpment-sale.php"><i class="far fa-arrow-right"></i>Equipment Sales & Supply</a>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- episode-single end -->
    <!-- Key Benefits -->
    <!-- Dolby Atmos Consultancy Section -->
    <section class="py-5 bg-light">
        <div class="container">
            <h2 class="text-center mb-5 section-heading" style="color:#46b8e9;">Why Choose Dolby Atmos Consultancy?</h2>
            <div class="row g-4">

                <!-- Card 1 -->
                <div class="col-md-4">
                    <div class="custom-card text-center p-4 h-100">
                        <div class="icon mb-3">
                            <i class="fas fa-headphones fa-3x text-primary"></i>
                        </div>
                        <h5 class="mb-2">Immersive 3D Audio</h5>
                        <p>We create soundscapes where audio moves all around you, with vertical precision and clarity.
                        </p>
                    </div>
                </div>

                <!-- Card 2 -->
                <div class="col-md-4">
                    <div class="custom-card text-center p-4 h-100">
                        <div class="icon mb-3">
                            <i class="fas fa-tools fa-3x text-success"></i>
                        </div>
                        <h5 class="mb-2">Certified System Calibration</h5>
                        <p>Our specialists fine-tune every channel and subwoofer for Dolby-certified performance.</p>
                    </div>
                </div>

                <!-- Card 3 -->
                <div class="col-md-4">
                    <div class="custom-card text-center p-4 h-100">
                        <div class="icon mb-3">
                            <i class="fas fa-theater-masks fa-3x text-danger"></i>
                        </div>
                        <h5 class="mb-2">Theatrical & Studio Expertise</h5>
                        <p>From large-scale cinemas to compact editing rooms, we adapt Atmos design to your space.</p>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- Custom CSS -->
    <style>
    .custom-card {
        background: #fff;
        border-radius: 20px;
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
        transition: all 0.3s ease-in-out;
    }

    .custom-card:hover {
        transform: translateY(-8px);
        box-shadow: 0 12px 25px rgba(0, 0, 0, 0.12);
    }

    .custom-card .icon i {
        transition: color 0.3s ease-in-out;
    }

    .custom-card:hover .icon i {
        color: #46b8e9 !important;
    }

    .section-heading {
        font-size: 2.2rem;
        font-weight: bold;
    }
    </style>


    <!-- Optional CSS -->
    <style>
    .hover-effect:hover {
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15) !important;
        transform: translateY(-5px);
        transition: all 0.3s ease;
    }
    </style>


</main>


<?php include('footer.php'); ?>