<?php include('header.php'); ?>


    <main class="main ">

        <!-- breadcrumb -->
        <div class="site-breadcrumb" style="background: url(assets/img/breadcrumb/01.jpg)">
            <div class="container">
                <h2 class="breadcrumb-title">Our Services</h2>
                <ul class="breadcrumb-menu">
                    <li><a href="index.html">Home</a></li>
                    <li class="active"></li>
                </ul>
            </div>
        </div>
        <!-- breadcrumb end -->


        <!-- episode-single -->
        <div class="episode-single py-100">
            <div class="container">
                <div class="row">
                   
                    <div class="col-lg-8 col-xl-9">
                        <div class="episode-single-content">
                            <div class="episode-single-img">
                                <img src="assets/img/episode/single.jpg" alt="">
                            </div>
                            <div class="episode-single-info">
                                <h3 class="title">Aesthetics and Lighting Designing</h3>
                                <p class="mb-20">
                                   A place where creativity is the core, needs to have a great vibe and a refreshing feeling. Aesthetics and lighting are the key to set the vibe and mood correct. Our aesthetics and lighting experts visually elevate your space to match up to the aural bliss.
                                </p>
                               <h3 class="title">System Designing</h3>
                                <p class="mb-20">
                                    Depending upon the type of work you undertake, or offer your customers we design the perfect system for your current and future needs. This includes making the list of equipment, cables, quantities Softwares, Plugins etc.
                                </p>
                                <div class="episode-single-more-img">
                                    <div class="row">
                                        <div class="col-md-6 mb-20">
                                            <img src="assets/img/episode/01.jpg" alt="">
                                        </div>
                                        <div class="col-md-6 mb-20">
                                            <img src="assets/img/episode/02.jpg" alt="">
                                        </div>
                                    </div>
                                </div>
                                <h3 class="title">Technical Training</h3>
                                <p class="mb-20">
                                  With the rapidly changing technologies, it is important for your technicians/engineersto understand and know the system, to do so, we train your team to understand the system and fluently use it.
                                </p>
                                <div class="my-4">
                                    <div class="mb-3">
                                        <h3 class="mb-3">Supply of Materials</h3>
                                        <p>We are key partners for various pro audio brands. So irrespective if it for a complex turn key project or a single requirement we have the product and expertise to assist with your requirement.</p>
                                    </div>
                                    <ul class="episode-single-list">
                                        <li><i class="far fa-check"></i><b>High-Quality Materials</b> – We ensure all supplied materials meet industry standards and client specifications for durability and performance..</li>
                                        <li><i class="far fa-check"></i><b>Timely Delivery</b> – Punctual delivery schedules are maintained to support uninterrupted project workflows.</li>
                                        <li><i class="far fa-check"></i><b>Wide Range of Products</b> – We offer a comprehensive selection of construction, electrical, and facility management materials.
                                        </li>
                                        <li><i class="far fa-check"></i><b>Cost-Effective Solutions</b> – Competitive pricing without compromising on quality to fit project budgets.</li>
                                        <li><i class="far fa-check"></i><b>Reliable Sourcing</b> – Materials are sourced from trusted manufacturers and verified vendors to guarantee consistency and reliability.</li>
                                    </ul>
                                </div>
                                <div class="my-4">
                                    <h3 class="mb-3">Aesthetics and Lighting Designing</h3>
                                    <p>A place where creativity is the core, needs to have a great vibe and a refreshing feeling. Aesthetics and lighting are the key to set the vibe and mood correct. Our aesthetics and lighting experts visually elevate your space to match up to the aural bliss.
                                    </p>
                                </div>
                            </div>  
                        </div>
                    </div>
                        <div class="col-lg-4 col-xl-3">
                    <div class="widget">
                        <h4 class="widget-title">Services</h4>
                        <div class="category-list">
                            <a href="Acoustic.php"><i class="far fa-arrow-right"></i>Acoustic consultancy Service</a>
                            <a href="Seamless.php"><i class="far fa-arrow-right"></i>Seamless System Integration</a>
                            <a href="Dolbyatmos.php"><i class="far fa-arrow-right"></i>Dolby Atmos consultancy</a>
                            <a href="hometheatres.php"><i class="far fa-arrow-right"></i>Home Theatres</a>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
        <!-- episode-single end -->

    </main>


    <?php include('footer.php'); ?>